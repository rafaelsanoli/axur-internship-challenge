# HtmlAnalyzer - Axur Technical Challenge

**Candidate:** Rafael Santos Oliveira  
**Position:** Software Development Intern  
**Date:** February 2026

## Compilation

```bash
javac HtmlAnalyzer.java
```

## Execution

```bash
java HtmlAnalyzer <URL>
```

Example:
```bash
java HtmlAnalyzer http://hiring.axreng.com/internship/example1.html
```

## Output Types

1. **Deepest text found** - The text content at the maximum depth level
2. **malformed HTML** - When HTML structure is invalid
3. **URL connection error** - When connection fails

## Implementation Details

- **Algorithm:** Stack-based depth tracking
- **Language:** Java 17
- **Dependencies:** None (Pure Java)
- **Validation:** Detects unclosed tags and crossed tags

## Test Results

All 7 test cases passed successfully (100%):
- ✓ Deepest text identification
- ✓ Tie-breaking rule (first text at max depth)
- ✓ Malformed HTML detection (crossed tags)
- ✓ Malformed HTML detection (unclosed tags)
- ✓ Connection error handling
- ✓ Empty lines and whitespace handling
- ✓ DOCTYPE and comments handling

---

**Developed by Rafael Santos Oliveira**
